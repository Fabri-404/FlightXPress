<?php
require '../../includes/config/database.php';
$db = conectarDB();

require '../../includes/funciones.php';
incluirTemplate('navbar');

// Consulta para obtener los usuarios
$query = 'SELECT id, nombre, apellido, email, password, rol FROM usuario';
$res = mysqli_query($db, $query);

// Manejo de errores si no se obtiene la lista de usuarios
if (!$res) {
    echo "<p>Error al obtener los usuarios.</p>";
    exit;
}
?>

<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover text-nowrap">
                            <thead>
                                <tr>
                                    <th>Opciones</th>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>apellido</th>
                                    <th>Email</th>
                                    <th>Rol</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                while ($reg = mysqli_fetch_assoc($res)) {
                                ?>
                                    <tr>
                                        <td>
                                            <a href="delete.php?cod=<?php echo $reg['id']; ?>" class="boton btn btn-danger btn-sm">Eliminar</a>
                                        </td>
                                        <td> <?php echo $reg['id']; ?></td>
                                        <td> <?php echo $reg['nombre'];?></td>
                                        <td> <?php echo $reg['apellido'];?></td>
                                        <td> <?php echo $reg['email']; ?></td>
                                        <td> <?php echo $reg['rol']; ?></td>
                                       

                                    </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>


                </div>
            </div>
        </div>
    </div>
</section>

<?php
incluirTemplate('footer');
?>
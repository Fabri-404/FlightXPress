<?php
require '../../includes/config/database.php';
$db = conectarDB();

if ($_POST) {
    // Obtener los datos del formulario y sanitizarlos
    $codigo_evento = mysqli_real_escape_string($db, $_POST['codigo_evento']);
    $servicios_adicionales = mysqli_real_escape_string($db, $_POST['servicios_adicionales']);
    $caracteristicas = mysqli_real_escape_string($db, $_POST['caracteristicas']);
    $precio = mysqli_real_escape_string($db, $_POST['precio']);
    $detalle = mysqli_real_escape_string($db, $_POST['detalle']);

    // Procesar la carga de imagen
    $imagen = null; // Inicializar la imagen
    if (isset($_FILES['img']) && $_FILES['img']['error'] === UPLOAD_ERR_OK) {
        $imgTmpPath = $_FILES['img']['tmp_name'];
        $imgName = $_FILES['img']['name'];
        $imgExtension = pathinfo($imgName, PATHINFO_EXTENSION);
        $imgNewName = uniqid("servicio_") . "." . $imgExtension;

        $uploadPath = '../../uploads/' . $imgNewName;
        if (move_uploaded_file($imgTmpPath, $uploadPath)) {
            $imagen = '/uploads/' . $imgNewName; // Ruta de la imagen en el servidor
        } else {
            echo "<script>alert('Error al cargar la imagen. Inténtelo de nuevo.');</script>";
            exit;
        }
    }

    // Consulta para insertar un nuevo servicio
    $con_sql = "INSERT INTO servicios (codigo_evento, servicios_adicionales, caracteristicas, precio, detalle, img) 
                VALUES ('$codigo_evento', '$servicios_adicionales', '$caracteristicas', '$precio', '$detalle', '$imagen')";
    $res = mysqli_query($db, $con_sql);

    if ($res) {
        echo "<script>
                alert('Servicio registrado correctamente.');
                window.location.href = '/TicketXPress/admin/servicios/list.php';
              </script>";
    } else {
        echo "<script>alert('Hubo un problema, contacta al administrador.');</script>";
    }
}
?>

<!-- Formulario HTML -->
<section class="content-header">
    <h1>Registrar Nuevo Servicio</h1>
</section>

<section class="content">
    <div class="card">
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Código Evento:</label>
                    <input type="text" name="codigo_evento" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Servicios Adicionales:</label>
                    <input type="text" name="servicios_adicionales" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Características:</label>
                    <input type="text" name="caracteristicas" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Precio:</label>
                    <input type="number" name="precio" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Detalle:</label>
                    <textarea name="detalle" class="form-control" required></textarea>
                </div>

                <div class="form-group">
                    <label>Imagen:</label>
                    <input type="file" name="img" class="form-control-file" required>
                </div>

                <button type="submit" class="btn btn-primary">Registrar Servicio</button>
                <a href="/TicketXPress/admin/servicios/list.php" class="btn btn-secondary">Cancelar</a>
            </form>
        </div>
    </div>
</section>



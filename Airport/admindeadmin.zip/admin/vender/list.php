
    <?php
        require '../../includes/config/database.php';
        require '../../includes/funciones.php';
        $db = conectarDB();

        incluirTemplate('navbar');
        
    ?>

        <section class="content-header">
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Administración</h1>
                        </div><!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Administración</a></li>
                                <li class="breadcrumb-item active">Vender</li>
                            </ol>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header">
                            <h1 class="m-0">Adminsitración de Vender</h1>
                        </div>
                        <div class="card-header">
                            <form action="" method="POST">
                                <div class="input-group">
                                    <input type="filter" name="filter" class="form-control form-control-lg" placeholder="Buscar" value="">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-lg btn-default">
                                            <i class="fa fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="card-body">
                            <div class="bd-example">
            
                <a href="" class="btn btn-primary btn-sm" target="_blank"><i class="fas fa-file-pdf"></i>Reporte</a>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body table-responsive p-0">
                                <table class="table table-hover text-nowrap">
                                    <thead>
                                        <tr>
                                            <th>Opciones</th>
                                            <th>Id</th>
                                            <th>Organizador </th>
                                            <th>Email</th>
                                            <th>Telefono</th>
                                            <th>Id evento</th>
                                            <th>Evento mensaje</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                            $con_sql='select * from vender';
                                            $res=mysqli_query($db,$con_sql);
                                            while($reg=$res->fetch_assoc())
                                            {
                                        ?>                                       
                                            <tr>
                                                <td>
                                                    <a href="view.php?cod=<?php echo $reg['id']; ?>" class="boton btn btn-warning btn-sm">Ver</a>
                                                    <a href="edit.php?cod=<?php echo $reg['id']; ?>" class="boton btn btn-primary btn-sm">Editar</a>
                                                    <a href="delete.php?cod=<?php echo $reg['id']; ?>" class="boton btn btn-danger btn-sm">Eliminar</a>
                                                </td>
                                                <td> <?php echo $reg['id'];?></td>
                                                <td> <?php echo $reg['organizador'];?></td>
                                                <td> <?php echo $reg['email'];?></td>
                                                <td> <?php echo $reg['telefono'];?></td>
                                                <td> <?php echo $reg['id_evento'];?></td>
                                                <td> <?php echo $reg['evento_mensaje'];?></td>

                                            </tr>
                                            <?php
                                            }
                                            ?>
                                    </tbody>
                                </table>
                            </div>

                           
                        </div>
                    </div>
                </div>
            </div>
        </section>
 
    



    <?php incluirTemplate('footer'); ?>
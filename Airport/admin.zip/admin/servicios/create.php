<?php
require '../../includes/config/database.php';
$db = conectarDB();
require '../../includes/funciones.php';
incluirTemplate('navbar');

// Verifica si se ha enviado el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los datos enviados del formulario
    $codigo_evento = $_POST['codigo_evento'];
    $servicios_adicionales = $_POST['servicios_adicionales'];
    $img = $_POST['img'];
    $caracteristicas = $_POST['caracteristicas'];
    $precio = $_POST['precio'];
    $detalle = $_POST['detalle'];

    // Insertar nuevo servicio en la base de datos con los nuevos campos
    $insertQuery = "INSERT INTO servicios (codigo_evento, servicios_adicionales, img, caracteristicas, precio, detalle) 
                    VALUES ('$codigo_evento', '$servicios_adicionales', '$img', '$caracteristicas', '$precio', '$detalle')";
    $insertResult = mysqli_query($db, $insertQuery);

    if ($insertResult) {
        echo "<script>
                alert('Servicio creado correctamente.');
                window.location.href = '/TicketXPress/admin/servicios/list.php';
              </script>";
        exit;
    } else {
        echo "<script>alert('Hubo un problema, contacta al administrador.');</script>";
    }
}
?>

<section class="content-header">
    <h1>Crear Nuevo Servicio</h1>
</section>

<section class="content">
    <div class="card">
        <div class="card-body">
            <!-- Formulario para crear un nuevo servicio -->
            <form method="POST" action="">
                <!-- Campo Código Evento -->
                <div class="form-group">
                <select name="id_evento" id="id_evento" class="form-control" required>
                            <?php
                            $con_sql="select * from evento";
                            $res=mysqli_query($db,$con_sql);
                            while($reg=$res->fetch_assoc()){
                            ?>
                            <option value="<?php echo $reg['id']?>"><?php echo $reg['titulo']." ".$reg['ubicacion']." ".$reg['precio']?></option>
                            
                            <?php
                            }
                            ?>
                        </select>

                </div>
                <!-- Campo Servicios Adicionales -->
                <div class="form-group">
                    <label>Servicios Adicionales:</label>
                    <input type="text" name="servicios_adicionales" class="form-control" placeholder="Servicios Adicionales" required>
                </div>
                <!-- Campo Imagen -->
                <div class="form-group">
                    <label>Imagen (URL):</label>
                    <input type="text" name="img" class="form-control" placeholder="URL de la imagen del servicio">
                </div>
                <!-- Campo Características -->
                <div class="form-group">
                    <label>Características:</label>
                    <textarea name="caracteristicas" class="form-control" placeholder="Características del servicio"></textarea>
                </div>
                <!-- Campo Precio -->
                <div class="form-group">
                    <label>Precio:</label>
                    <input type="number" name="precio" class="form-control" placeholder="Precio del servicio" required step="0.01" min="0">
                </div>
                <!-- Campo Detalle -->
                <div class="form-group">
                    <label>Detalle:</label>
                    <textarea name="detalle" class="form-control" placeholder="Detalle del servicio"></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">Guardar Servicio</button>
                <a href="/TicketXPress/admin/servicios/list.php" class="btn btn-secondary">Volver</a>
            </form>
        </div>
    </div>
</section>

<?php 
incluirTemplate('footer');
?>

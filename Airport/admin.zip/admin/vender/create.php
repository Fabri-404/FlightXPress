<?php
require '../../includes/config/database.php';
$db = conectarDB();
require '../../includes/funciones.php';
incluirTemplate('navbar');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $organizador = $_POST['organizador'];
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];
    $id_evento = $_POST['id_evento'];
    $evento_mensaje = $_POST['evento_mensaje'];

    // Insertar nuevo registro
    $insertQuery = "INSERT INTO vender (organizador, email, telefono, id_evento, evento_mensaje) 
                    VALUES ('$organizador', '$email', '$telefono', $id_evento, '$evento_mensaje')";
    $insertResult = mysqli_query($db, $insertQuery);

    if ($insertResult) {
        echo "<script>
                alert('Ticket registrado correctamente.');
                window.location.href = '/TicketXPress/admin/vender/list.php';
              </script>";
        exit;
    } else {
        echo "<script>alert('Hubo un problema, contacta al administrador.');</script>";
    }
}
?>

<section class="content-header">
    <h1>Crear Nuevo Ticket</h1>
</section>
<section class="content">
    <div class="card">
        <div class="card-body">
            <form method="POST" action="">
                <div class="form-group">
                    <label>Organizador:</label>
                    <input type="text" name="organizador" class="form-control" placeholder="Organizador" required>
                </div>
                <div class="form-group">
                    <label>Email:</label>
                    <input type="email" name="email" class="form-control" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <label>Teléfono:</label>
                    <input type="text" name="telefono" class="form-control" placeholder="Teléfono" required>
                </div>
                <div class="form-group">
                    <label>ID Evento:</label>
                    <input type="number" name="id_evento" class="form-control" placeholder="ID del Evento" required>
                </div>
                <div class="form-group">
                    <label>Mensaje del Evento:</label>
                    <textarea name="evento_mensaje" class="form-control" placeholder="Escribe el mensaje del evento aquí" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                <a href="/TicketXPress/admin/vender/list.php" class="btn btn-secondary">Volver</a>
            </form>
        </div>
    </div>
</section>

<?php 
incluirTemplate('footer');
?>
